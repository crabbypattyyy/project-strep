# throat segmentation > 2024-01-15 8:49am
https://universe.roboflow.com/project-teehl/throat-segmentation

Provided by a Roboflow user
License: CC BY 4.0

